from __future__ import annotations

import json
from typing import Any


def generate_conflict_clarification_message(
    user_message: str,
    conflict_action: dict[str, Any],
    existing_record: dict[str, Any],
    options: list[str] | None = None,
) -> str:
    """
    Generates a user-friendly conflict clarification message.

    Important:
    This function only generates text.
    It must not decide, execute, or modify the action.
    """

    action = conflict_action.get("action")
    data = conflict_action.get("data") or {}
    options = options or ["add_anyway", "update_existing", "cancel"]

    # If you already have an LLM wrapper in your project, replace this
    # fallback with your normal LLM call.
    #
    # Example:
    # response = llm.invoke(prompt)
    # return response.content.strip()

    prompt = f"""
You are AMMA, an AI Money Management Assistant.

The system is waiting for the user to resolve a possible duplicate/conflict.

User's latest message:
{user_message}

Pending action:
{json.dumps(conflict_action, ensure_ascii=False, indent=2)}

Existing similar record:
{json.dumps(existing_record, ensure_ascii=False, indent=2)}

Available user choices:
{json.dumps(options, ensure_ascii=False)}

Your job:
Generate a short, clear message telling the user that their new request may duplicate an existing saved record.

Rules:
- Do not execute anything.
- Do not say the action is completed.
- Mention the existing record details.
- Ask the user to choose one of these exact options in natural language:
  1. add anyway
  2. update existing
  3. cancel
- Keep the message friendly and concise.
- Do not return JSON.
"""

    # Temporary fallback until connected to your LLM wrapper.
    if action == "create_expense":
        return (
            "I found a possible duplicate expense already saved.\n\n"
            "Existing expense:\n"
            f"- ID: {existing_record.get('id')}\n"
            f"- Description: {existing_record.get('description') or data.get('description')}\n"
            f"- Amount: {existing_record.get('amount') or data.get('amount')}\n"
            f"- Category: {existing_record.get('category_name') or data.get('category')}\n"
            f"- Date: {existing_record.get('transaction_date') or data.get('transaction_date')}\n\n"
            "Do you want to add anyway, update existing, or cancel?"
        )

    if action == "create_loan":
        return (
            "I found a possible duplicate loan already saved.\n\n"
            "Existing loan:\n"
            f"- ID: {existing_record.get('id')}\n"
            f"- Person: {existing_record.get('person_name') or data.get('person_name')}\n"
            f"- Amount: {existing_record.get('amount') or data.get('amount')}\n"
            f"- Date: {existing_record.get('date_created') or data.get('date_created')}\n\n"
            "Do you want to add anyway, update existing, or cancel?"
        )

    return (
        "I found a possible duplicate record. "
        "Do you want to add anyway, update existing, or cancel?"
    )