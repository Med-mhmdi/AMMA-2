from __future__ import annotations

from typing import Any

from app.graph.state import AgentState
from app.workflow.common import append_trace, is_decline_message
from app.agents.conflict_response_agent import generate_conflict_clarification_message


# ============================================================
# Helpers
# ============================================================

def _norm(value: Any) -> str:
    return str(value or "").strip().lower()


def _same_number(left: Any, right: Any) -> bool:
    try:
        return float(left) == float(right)
    except (TypeError, ValueError):
        return False


def _get_category_name_from_expense(expense: dict[str, Any]) -> str | None:
    category = expense.get("category")

    if isinstance(category, dict):
        return category.get("name")

    return expense.get("category_name") or expense.get("category")


def _find_duplicate_expense(
    data: dict[str, Any],
    tool_context: dict[str, Any],
) -> dict[str, Any] | None:
    expenses = tool_context.get("expenses") or []
    requested_description = _norm(data.get("description"))
    requested_amount = data.get("amount")
    requested_date = _norm(data.get("transaction_date"))
    requested_type = _norm(data.get("type") or "outcome")
    requested_category = _norm(
        data.get("category")
        or data.get("category_name")
        or (tool_context.get("matched_category") or {}).get("name")
    )

    if not requested_description or requested_amount in [None, ""]:
        return None

    for expense in expenses:
        same_description = _norm(expense.get("description")) == requested_description
        same_amount = _same_number(expense.get("amount"), requested_amount)
        same_type = _norm(expense.get("type") or "outcome") == requested_type

        expense_date = _norm(expense.get("transaction_date") or expense.get("date"))
        same_date = not requested_date or expense_date == requested_date

        expense_category = _norm(_get_category_name_from_expense(expense))
        same_category = not requested_category or expense_category == requested_category

        if same_description and same_amount and same_type and same_date and same_category:
            return expense

    return None


def _find_duplicate_loan(
    data: dict[str, Any],
    tool_context: dict[str, Any],
) -> dict[str, Any] | None:
    loans = tool_context.get("loans") or []
    requested_person = _norm(data.get("person_name"))
    requested_type = _norm(data.get("type"))
    requested_amount = data.get("amount")
    requested_date = _norm(data.get("date_created"))

    if not requested_person or requested_amount in [None, ""]:
        return None

    for loan in loans:
        same_person = _norm(loan.get("person_name")) == requested_person
        same_amount = _same_number(loan.get("amount"), requested_amount)
        same_type = not requested_type or _norm(loan.get("type")) == requested_type

        loan_date = _norm(loan.get("date_created") or loan.get("created_at"))
        same_date = not requested_date or loan_date == requested_date

        if same_person and same_amount and same_type and same_date:
            return loan

    return None


def _build_conflict_question(action: str, data: dict[str, Any], existing_record: dict[str, Any]) -> str:
    if action == "create_expense":
        return (
            "I found a similar expense already saved.\n"
            f"- Description: {data.get('description')}\n"
            f"- Amount: {data.get('amount')}\n"
            f"- Date: {data.get('transaction_date')}\n\n"
            "What do you want to do: add anyway, update existing, or cancel?"
        )

    if action == "create_loan":
        return (
            "I found a similar loan already saved.\n"
            f"- Person: {data.get('person_name')}\n"
            f"- Amount: {data.get('amount')}\n"
            f"- Date: {data.get('date_created')}\n\n"
            "What do you want to do: add anyway, update existing, or cancel?"
        )

    return "I found a possible duplicate. Do you want to continue anyway, update existing, or cancel?"


def _parse_conflict_decision(message: str | None) -> str:
    text = _norm(message)

    if is_decline_message(text):
        return "cancel"

    add_anyway_phrases = [
        "add anyway",
        "create anyway",
        "keep both",
        "continue anyway",
        "do it anyway",
        "yes add",
        "yes create",
    ]

    update_phrases = [
        "update existing",
        "update it",
        "replace existing",
        "replace old",
        "edit existing",
        "use existing",
    ]

    if any(phrase in text for phrase in add_anyway_phrases):
        return "add_anyway"

    if any(phrase in text for phrase in update_phrases):
        return "update_existing"

    return "unclear"


# ============================================================
# Conflict check
# ============================================================

def conflict_check_node(state: AgentState) -> AgentState:
    """
    Checks whether a valid and confirmed/allowed action conflicts with an
    existing backend record.

    This is not validation. Validation checks if the action is legal/complete.
    This node checks if the legal action is probably a duplicate.
    """

    if state.get("skip_conflict_check"):
        return {
            "conflict_check": {
                "has_conflict": False,
                "skipped": True,
                "reason": "skip_conflict_check flag is true.",
            },
            "trace": append_trace(state, "ConflictCheckNode"),
        }

    extracted_action = state.get("extracted_action") or {}
    tool_context = state.get("tool_context") or {}
    action = extracted_action.get("action")
    data = extracted_action.get("data") or {}

    existing_record = None
    conflict_type = None

    if action == "create_expense" and not extracted_action.get("auto_create_missing_category"):
        existing_record = _find_duplicate_expense(data, tool_context)
        conflict_type = "possible_duplicate_expense"

    elif action == "create_loan":
        existing_record = _find_duplicate_loan(data, tool_context)
        conflict_type = "possible_duplicate_loan"

    if not existing_record:
        return {
            "conflict_check": {
                "has_conflict": False,
                "action": action,
            },
            "trace": append_trace(state, "ConflictCheckNode"),
        }

    conflict_action = {
        **extracted_action,
        "conflict_type": conflict_type,
        "existing_record": existing_record,
    }

    return {
        "conflict_check": {
            "has_conflict": True,
            "awaiting_conflict_resolution": True,
            "conflict_type": conflict_type,
            "conflict_action": conflict_action,
            "existing_record": existing_record,
            "question": _build_conflict_question(action, data, existing_record),
            "options": ["add_anyway", "update_existing", "cancel"],
        },
        "trace": append_trace(state, "ConflictCheckNode"),
    }


def conflict_resolution_prepare_node(state: AgentState) -> AgentState:
    conflict_check = state.get("conflict_check") or {}

    conflict_action = conflict_check.get("conflict_action") or {}
    existing_record = conflict_check.get("existing_record") or {}
    options = conflict_check.get("options") or ["add_anyway", "update_existing", "cancel"]

    question = generate_conflict_clarification_message(
        user_message=state.get("message") or "",
        conflict_action=conflict_action,
        existing_record=existing_record,
        options=options,
    )

    return {
        "validation": {
            "is_valid": False,
            "needs_user_clarification": True,
            "awaiting_conflict_resolution": True,
            "question": question,
            "conflict_action": conflict_action,
            "conflict_options": options,
            "existing_record": existing_record,
        },
        "conflict_resolution": {
            "awaiting_conflict_resolution": True,
            "question": question,
            "conflict_action": conflict_action,
            "existing_record": existing_record,
            "options": options,
        },
        "trace": append_trace(state, "ConflictResolutionPrepareNode"),
    }


def conflict_resolution_handler_node(state: AgentState) -> AgentState:
    """
    Handles the user's answer after conflict_resolution_prepare_node.

    Supported decisions:
    - add_anyway: run the original create action and skip conflict check.
    - update_existing: convert create_expense/create_loan into update action.
    - cancel: clear memory.
    """

    working_memory = state.get("loaded_working_memory") or {}
    conflict_action = working_memory.get("conflict_action")
    existing_record = working_memory.get("conflict_existing_record")
    message = state.get("message")

    if not conflict_action:
        return {
            "execution_result": {
                "status": "failed",
                "message": "There is no saved conflict to resolve.",
            },
            "trace": append_trace(state, "ConflictResolutionHandlerNode"),
        }

    decision = _parse_conflict_decision(message)

    if decision == "cancel":
        return {
            "execution_result": {
                "status": "cancelled",
                "message": "Okay, I cancelled the duplicated action.",
            },
            "conflict_resolution": {
                "decision": "cancel",
            },
            "trace": append_trace(state, "ConflictResolutionHandlerNode"),
        }

    if decision == "unclear":
        existing_record = existing_record or conflict_action.get("existing_record") or {}

        question = generate_conflict_clarification_message(
            user_message=message or "",
            conflict_action=conflict_action,
            existing_record=existing_record,
            options=working_memory.get("conflict_options") or ["add_anyway", "update_existing", "cancel"],
        )

        return {
            "validation": {
                "is_valid": False,
                "needs_user_clarification": True,
                "awaiting_conflict_resolution": True,
                "question": question,
            },
            "conflict_resolution": {
                "awaiting_conflict_resolution": True,
                "decision": "unclear",
                "question": question,
                "conflict_action": conflict_action,
                "existing_record": existing_record,
                "options": working_memory.get("conflict_options") or ["add_anyway", "update_existing", "cancel"],
            },
            "trace": append_trace(state, "ConflictResolutionHandlerNode"),
        }

    if decision == "add_anyway":
        prepared_action = {
            **conflict_action,
            "confirmed": True,
        }
        prepared_action.pop("existing_record", None)
        prepared_action.pop("conflict_type", None)

        return {
            "intent": "command",
            "extracted_action": prepared_action,
            "confirmation_approved": True,
            "skip_confirmation": True,
            "skip_conflict_check": True,
            "conflict_resolution": {
                "decision": "add_anyway",
            },
            "trace": append_trace(state, "ConflictResolutionHandlerNode"),
        }

    if decision == "update_existing":
        action = conflict_action.get("action")
        data = conflict_action.get("data") or {}
        existing_record = existing_record or conflict_action.get("existing_record") or {}

        if action == "create_expense":
            updated_data = {
                **data,
                "expense_id": existing_record.get("id"),
                "id": existing_record.get("id"),
            }
            prepared_action = {
                "action": "update_expense",
                "data": updated_data,
                "confirmed": True,
            }

        elif action == "create_loan":
            updated_data = {
                **data,
                "loan_id": existing_record.get("id"),
                "id": existing_record.get("id"),
            }
            prepared_action = {
                "action": "update_loan",
                "data": updated_data,
                "confirmed": True,
            }

        else:
            return {
                "execution_result": {
                    "status": "failed",
                    "message": f"Update existing is not supported for action: {action}",
                },
                "trace": append_trace(state, "ConflictResolutionHandlerNode"),
            }

        return {
            "intent": "command",
            "extracted_action": prepared_action,
            "confirmation_approved": True,
            "skip_confirmation": True,
            "skip_conflict_check": True,
            "conflict_resolution": {
                "decision": "update_existing",
                "existing_record": existing_record,
            },
            "trace": append_trace(state, "ConflictResolutionHandlerNode"),
        }

    return {
        "execution_result": {
            "status": "failed",
            "message": "Unsupported conflict resolution decision.",
        },
        "trace": append_trace(state, "ConflictResolutionHandlerNode"),
    }
